#include <stdio.h>

extern int yyparse();   
extern FILE *yyin;     

int main(int argc, char **argv) {
    printf("=== GLSimpleSQL Interpreter ===\n");

   
    if (argc > 1) {
        yyin = fopen(argv[1], "r");
        if (!yyin) {
            printf("Erreur : impossible d'ouvrir le fichier %s\n", argv[1]);
            return 1;
        }
    }

    // Lancer l'analyse
    yyparse();

    printf("=== Fin d'analyse ===\n");
    return 0;
}
